# database-repo

This is **not** a copy of the running database — it's the source of truth for schema.
Real databases don't live in git; what does is versioned migration files, so schema changes
are reviewed, tested, and applied the same way code is.

## Structure
- `migrations/` — sequential, numbered SQL migration files (never edit an old one — add a new one)
- `seeds/` — sample data for local dev
- `.github/workflows/ci.yml` — spins up a throwaway Postgres, runs all migrations to verify they apply cleanly

## Local dev
```
createdb myapp_dev
psql myapp_dev < migrations/0001_init.sql
psql myapp_dev < migrations/0002_add_users_email_index.sql
psql myapp_dev < seeds/dev_seed.sql
```

## How this connects to backend-repo
`backend-repo` never creates or alters tables at runtime. A separate deploy step runs pending
migrations from this repo against the real DB *before* the new backend version goes live.
