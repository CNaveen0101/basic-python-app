-- Speed up lookups by email
CREATE INDEX idx_users_email ON users(email);
