INSERT INTO users (email) VALUES
  ('alice@example.com'),
  ('bob@example.com');
