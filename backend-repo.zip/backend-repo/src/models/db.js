// Connects to the schema defined in database-repo/migrations
const { Pool } = require("pg");
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

module.exports = {
  ping: async () => {
    const r = await pool.query("SELECT 1");
    return r.rowCount === 1;
  },
};
