const express = require("express");
const router = express.Router();
const db = require("../models/db");

router.get("/", async (req, res) => {
  const dbOk = await db.ping();
  res.json({ status: "ok", db: dbOk });
});

module.exports = router;
