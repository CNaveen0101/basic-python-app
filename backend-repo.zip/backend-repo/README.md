# backend-repo

Node/Express API server. Owns all database access — `frontend-repo` never connects to the DB directly, only calls this API.
Schema is managed separately in `database-repo`; this repo just runs SQL against whatever schema is currently deployed.

## Structure
- `src/routes/` — API endpoints
- `src/models/` — DB query layer
- `tests/` — unit + integration tests
- `.github/workflows/ci.yml` — test, build Docker image, push to registry

## Local dev
```
npm install
npm run dev   # requires DATABASE_URL env var pointing at a local Postgres
```

## Deploy
CI builds a Docker image on merge to `main`, pushes to the container registry, then triggers a rolling deploy.
