# frontend-repo

React frontend for the app. Talks to `backend-repo`'s API — never touches the database directly.

## Structure
- `src/components/` — reusable UI components
- `src/pages/` — route-level views
- `.github/workflows/ci.yml` — lint, test, build on every PR

## Local dev
```
npm install
npm run dev
```

## Deploy
Merges to `main` auto-deploy to staging via CI. Production deploy is a manual promote step.
