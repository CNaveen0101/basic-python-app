import Button from "../components/Button";

// Calls backend-repo's REST API — see /api/config.js for base URL
export default function Home() {
  return <Button onClick={() => fetch("/api/health")}>Check API</Button>;
}
